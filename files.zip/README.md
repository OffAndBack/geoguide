# GéoGuide 📍

Guide touristique intelligent basé sur la géolocalisation, propulsé par **Claude AI (Anthropic)**.

## Fonctionnalités

- 📍 **Géolocalisation** — détecte automatiquement votre position
- 🗺️ **Lieux à proximité** — liste et carte des sites culturels autour de vous
- 🤖 **Explications IA** — Claude génère des descriptions historiques et culturelles en streaming
- 🌍 **Multilingue** — FR, EN, ES, DE, IT
- 🎨 **Styles variés** — détaillé, court, anecdotes, adapté enfants
- 📱 **PWA** — installable sur mobile comme une app native

## Stack technique

- **Frontend** — HTML / CSS / JS vanilla (zéro dépendance)
- **Backend** — Vercel Edge Functions (serverless)
- **IA** — Anthropic Claude claude-sonnet-4-20250514 (streaming SSE)
- **Déploiement** — Vercel

## Installation locale

```bash
# Cloner le dépôt
git clone https://github.com/TON_USERNAME/geoguide.git
cd geoguide

# Installer Vercel CLI
npm i -g vercel

# Configurer la clé API (créer un fichier .env.local)
echo "GEMINI_API_KEY=sk-ant-VOTRE_CLE" > .env.local

# Lancer en local
vercel dev
```

## Déploiement Vercel

1. Pusher sur GitHub
2. Importer le projet sur [vercel.com](https://vercel.com)
3. Ajouter la variable d'environnement `GEMINI_API_KEY` dans les settings Vercel
4. Deploy !

## Variables d'environnement

| Variable | Description |
|---|---|
| `GEMINI_API_KEY` | Clé API Google Gemini — 100% GRATUITE, sans CB. Obtenir sur https://aistudio.google.com/apikey |

## Structure du projet

```
geoguide/
├── index.html          # App principale
├── style.css           # Styles (dark mode inclus)
├── app.js              # Logique frontend
├── manifest.json       # PWA manifest
├── vercel.json         # Config Vercel
└── api/
    └── explain.js      # Edge function → Anthropic API
```

## Licence

MIT
